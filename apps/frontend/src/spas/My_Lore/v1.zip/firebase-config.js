// Firebase web config for project sids-lean-canvas (public client keys)
// Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyC7gqnqLoZn5wXnrDkb9yKJx4wqsB9FYLA",
    authDomain: "awesome-notes-01.firebaseapp.com",
    projectId: "awesome-notes-01",
    storageBucket: "awesome-notes-01.firebasestorage.app",
    messagingSenderId: "432217252691",
    appId: "1:432217252691:web:c394293157f3f234f777a6"
  };